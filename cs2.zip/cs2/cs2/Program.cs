﻿using ClickableTransparentOverlay;
using cs2;
using ImGuiNET;
using Swed64;
using System.Net;
using System.Numerics;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.InteropServices;
using System.Drawing;



namespace CS2MULTI
{
    class Program : Overlay
    {
        [DllImport("user32.dll")]

        static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

        [StructLayout(LayoutKind.Sequential)]

        public struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        public static RECT GetWindowRect(IntPtr hWnd)
        {
            RECT rect = new RECT();
            GetWindowRect(hWnd, out rect);
            return rect;

        }


        Swed swed = new Swed("cs2");
        Entity localPlr = new Entity();
        ImDrawListPtr drawList;

        List<Entity> entities = new List<Entity>();
        List<Entity> enemies = new List<Entity>();
        List<Entity> tm8s = new List<Entity>();
        Offsets offsets = new Offsets();

        IntPtr client;

        Vector4 teammateColor = new Vector4(0, 0, 1, 1);
        Vector4 enemyColor = new Vector4(1, 0, 0, 1);
        Vector4 hpBar = new Vector4(0, 1, 0, 1);
        Vector4 hpText = new Vector4(0, 0, 0, 1);

        Vector2 windowLocation = new Vector2(0, 0);
        Vector2 windowSize = new Vector2(1366, 768);
        private Vector2 WindowSize;
        Vector2 lineOrigin = new Vector2(1366 / 2, 768);
        Vector2 windowCenter = new Vector2(1366 / 2, 768 / 2);



        bool enableEsp = true;
        


        bool enableTeamLine = true;
        bool enableTeamBox = true;
        bool enableTeamDot = true;
        bool enableTeamHPBAR = true;
        bool enableTeamDistance = true;

        bool enableEnemyLine = true;
        bool enableEnemyBox = true;
        bool enableEnemyDot = true;
        bool enableEnemyHPBAR = true;
        bool enableEnemyDistance = true;



        protected override void Render()
        {
            //only render stuff here

            DrawMenu();
            DrawOverlay();
            Esp();
            ImGui.End();
        }



        void Esp()
        {
            drawList = ImGui.GetWindowDrawList(); // important to get the overlay
            if (enableEsp)
            {
                try
                {
                    foreach (var entity in entities)
                    {
                        if (entity.teamNum == localPlr.teamNum)
                        {
                            DrawVisuals(entity, teammateColor, enableTeamLine, enableTeamBox, enableTeamDot, enableTeamHPBAR, enableTeamDistance);
                        }
                        else
                        {
                            DrawVisuals(entity, enemyColor, enableEnemyLine, enableEnemyBox, enableEnemyDot, enableEnemyHPBAR, enableEnemyDistance);
                        }
                    }
                } catch { }
            }
        }
        ViewMatrix ReadMatrix(IntPtr matrixAddress)
        {
            var viewMatrix = new ViewMatrix();
            var floatMatrix = swed.ReadMatrix(matrixAddress);


            viewMatrix.m11 = floatMatrix[0];
            viewMatrix.m12 = floatMatrix[1];
            viewMatrix.m13 = floatMatrix[2];
            viewMatrix.m14 = floatMatrix[3];
            viewMatrix.m21 = floatMatrix[4];
            viewMatrix.m22 = floatMatrix[5];
            viewMatrix.m23 = floatMatrix[6];
            viewMatrix.m24 = floatMatrix[7];
            viewMatrix.m31 = floatMatrix[8];
            viewMatrix.m32 = floatMatrix[9];
            viewMatrix.m33 = floatMatrix[10];
            viewMatrix.m34 = floatMatrix[11];
            viewMatrix.m41 = floatMatrix[12];
            viewMatrix.m42 = floatMatrix[13];
            viewMatrix.m43 = floatMatrix[14];
            viewMatrix.m44 = floatMatrix[15];

            return viewMatrix;

        }

        Vector2 WorldToScreen(ViewMatrix matrix, Vector3 pos, int height, int width)
        {
            Vector2 screenCoords = new Vector2();

            float screenW = (matrix.m41 * pos.X) + (matrix.m42 * pos.Y) + (matrix.m43 * pos.Z) + matrix.m44;

            if (screenW > 0.001f)
            {
                float screenX = (matrix.m11 * pos.X) + (matrix.m12 * pos.Y) + (matrix.m13 * pos.Z) + matrix.m14;
                float screenY = (matrix.m21 * pos.X) + (matrix.m22 * pos.Y) + (matrix.m23 * pos.Z) + matrix.m24;

                float camX = width / 2;
                float camY = height / 2;

                float X = camX + (camX * screenX / screenW);
                float Y = camY - (camY * screenY / screenW);

                screenCoords.X = X;
                screenCoords.Y = Y;
                return screenCoords;
            }
            else
            {
                return new Vector2(-99, -99);
            }
        }
        void DrawMenu()
        {
            ImGui.Begin("annihilate.cs2");

            if (ImGui.BeginTabBar("Tabs"))
            {
                if (ImGui.BeginTabItem("Visuals"))
                {
                    ImGui.Text("ESP");
                    ImGui.Separator();
                    ImGui.Checkbox("ESP", ref enableEsp);
                    ImGui.Checkbox("Team Dot", ref enableTeamDot);
                    ImGui.Checkbox("Team Line", ref enableTeamLine);
                    ImGui.Checkbox("Team Distance", ref enableTeamDistance);
                    ImGui.Checkbox("Team Box", ref enableTeamBox);
                    ImGui.Checkbox("Team HP", ref enableTeamHPBAR);

                    ImGui.Text("Enemy configs");
                    ImGui.Separator();
                    ImGui.Checkbox("Enemy Dot", ref enableEnemyDot);
                    ImGui.Checkbox("Enemy Line", ref enableEnemyLine);
                    ImGui.Checkbox("Enemy Distance", ref enableEnemyDistance);
                    ImGui.Checkbox("Enemy Box", ref enableEnemyBox);
                    ImGui.Checkbox("Enemy HP", ref enableEnemyHPBAR);


   
                    ImGui.Text("Color configs");
                    ImGui.Separator();
                    ImGui.ColorPicker4("Team Color", ref teammateColor);
                    ImGui.ColorPicker4("Enemy Color", ref enemyColor);
                    ImGui.EndTabItem();
                }
                if (ImGui.BeginTabItem("Aimbot"))
                {
                    ImGui.LabelText("Coming soon", "Hi");
                    ImGui.EndTabItem();
                }
                if (ImGui.BeginTabItem("Triggerbot"))
                {
                    ImGui.LabelText("Coming soon", "Hi");
                    ImGui.EndTabItem();
                }
                if (ImGui.BeginTabItem("Customization/Misc"))
                {
                    ImGui.LabelText("Hello", "Hi");
                    ImGui.EndTabItem();
                }
            }
            ImGui.EndTabBar();
        }

        void DrawOverlay()
        {

            ImGui.SetNextWindowSize(WindowSize);
            ImGui.SetNextWindowPos(windowLocation);
            ImGui.Begin("overlay", ImGuiWindowFlags.NoDecoration
                | ImGuiWindowFlags.NoBackground
                | ImGuiWindowFlags.NoBringToFrontOnFocus
                | ImGuiWindowFlags.NoMove
                | ImGuiWindowFlags.NoInputs
                | ImGuiWindowFlags.NoCollapse
                | ImGuiWindowFlags.NoScrollbar
                | ImGuiWindowFlags.NoScrollWithMouse
            );
        }
        void MainLogic()
        {
            var window = GetWindowRect(swed.GetProcess().MainWindowHandle);
            windowLocation = new Vector2(window.left, window.top);
            WindowSize = Vector2.Subtract(new Vector2(window.right, window.bottom), windowLocation);
            lineOrigin = new Vector2(windowLocation.X + windowSize.X / 2, window.bottom);
            windowCenter = new Vector2(lineOrigin.X, window.bottom - WindowSize.Y / 2);

            client = swed.GetModuleBase("client.dll");
            while (true)
            {
                ReloadEntities();
                Thread.Sleep(3);
            }
        }

        void ReloadEntities()
        {
            entities.Clear();
            tm8s.Clear();
            enemies.Clear();
            localPlr.address = swed.ReadPointer(client, offsets.localP);
            UpdateEntity(localPlr);

            UpdateEntities();
        }
        void UpdateEntity(Entity entity)
        {


            entity.health = swed.ReadInt(entity.address, offsets.health);
            entity.teamNum = swed.ReadInt(entity.address, offsets.teamNum);
            entity.origin = swed.ReadVec(entity.address, offsets.origin);


            // 3d
            entity.origin = swed.ReadVec(entity.address, offsets.origin);
            entity.ViewOffset = new Vector3(0, 0, 65); // simulate view offset
            entity.abs = Vector3.Add(entity.origin, entity.ViewOffset);
            // 2d
            var currentViewmatrix = ReadMatrix(client + offsets.ViewMatrix);
            entity.originScreenPos = Vector2.Add(WorldToScreen(currentViewmatrix, entity.origin, (int)WindowSize.X, (int)WindowSize.Y), windowLocation);
            entity.absScreenPos = Vector2.Add(WorldToScreen(currentViewmatrix, entity.abs, (int)WindowSize.X, (int)WindowSize.Y), windowLocation);
        }

        bool IsPixelInsideScreen(Vector2 pixel)
        {
            return pixel.X > windowLocation.X && pixel.X < windowLocation.X + WindowSize.X && pixel.Y > windowLocation.Y && pixel.Y < WindowSize.Y + windowLocation.Y;
        }
        void UpdateEntities()
        {
            for (int i = 0; i < 64; i++)
            {
                IntPtr tempEntAddress = swed.ReadPointer(client, offsets.entityList + i * 0x08);

                if (tempEntAddress == IntPtr.Zero)
                    continue;

                Entity entity = new Entity();
                entity.address = tempEntAddress;

                UpdateEntity(entity);

                if (entity.health < 1 || entity.health > 100)
                    continue;

                if (!entities.Any(element => element.origin == entity.origin))
                {
                    entities.Add(entity);

                    if (entity.teamNum == localPlr.teamNum)
                    {
                        tm8s.Add(entity);
                    }

                    else
                    {
                        enemies.Add(entity);
                    }
                }

            }
        }

        void DrawVisuals(Entity entity, Vector4 color, bool line, bool box, bool dot, bool healthBar, bool distance)
        {
            // check if 2d position valid
            if (IsPixelInsideScreen(entity.originScreenPos))
            {
                // convert our colors to uints
                uint uintColor = ImGui.ColorConvertFloat4ToU32(color);
                uint uintHealthTextColor = ImGui.ColorConvertFloat4ToU32(hpText);
                uint uintHealthBarColor = ImGui.ColorConvertFloat4ToU32(hpBar);
                Vector2 boxWidth = new Vector2(entity.originScreenPos.Y - entity.absScreenPos.Y / 2, 0f); // divide height by 2 to simulate width.
                Vector2 boxStart = Vector2.Subtract(entity.absScreenPos, boxWidth); // get left topmost I think
                Vector2 boxEnd = Vector2.Add(entity.originScreenPos, boxWidth); // get bottom right
                                                                                // calculate health bar stuff
                float barPercent = entity.health / 100f;
                Vector2 barHeight = new Vector2(0, barPercent * (entity.originScreenPos.Y - entity.absScreenPos.Y)); // calculate height like before, but with 2d coords
                Vector2 barStart = Vector2.Subtract(Vector2.Subtract(entity.originScreenPos, boxWidth), barHeight); // get position beside box using the box width
                Vector2 barEnd = Vector2.Subtract(entity.originScreenPos, Vector2.Add(boxWidth, new Vector2(-4, 0))); // get the bottom right end of the bar 

                // finally draw

                if (line)
                {
                    {
                        drawList.AddLine(lineOrigin, entity.originScreenPos, uintColor, 3); // draw line to feet of entities if (box)
                    }
                }
                if (box)
                {
                    { 
                        drawList.AddRect(boxStart, boxEnd, uintColor, 3); // box around character
                    }
                }
                if (dot)
                {
                    drawList.AddCircleFilled(entity.originScreenPos, 5, uintColor);
                }
                if (healthBar)
                {
                    drawList.AddText(entity.originScreenPos, uintHealthTextColor, $"hp: {entity.health}"); 
                    drawList.AddRectFilled(barStart, barEnd, uintHealthBarColor);
                }
            }
        }

        static void Main(string[] args)
        {
            //logic stuff here

            Program program = new Program();
            program.Start().Wait();

            Thread mlt = new Thread(program.MainLogic) { IsBackground = true };
            mlt.Start();
        }
    }
}