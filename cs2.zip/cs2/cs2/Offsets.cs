﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cs2
{
    public class Offsets
    {
        public int ViewMatrix = 0x180F330;//got from the CS2 dumper because the ones i found didn't work at all
        public int localP = 0x16BC4A8;
        public int entityList = 0x16C9190;
        public int GameSceneNode = 0x310;

        public int health = 0x32c;
        public int origin = 0xCD8;
        public int teamNum = 0x3bf;
        public int jumpFlag = 0x3c8;

        //gospel month turtle submit seven dwarf expect cinnamon abandon throw gesture stage
    }
}
